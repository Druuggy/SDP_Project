package app;

import java.util.ArrayList;

public class GiftsGroup {
	private String occasion;
	private ArrayList<Gift>giftsList;

	public GiftsGroup( String listName){

		this.occasion = listName;
		this.giftsList = new ArrayList<Gift>();
	}

	public ArrayList<Gift> getGiftsList(){
		return this.giftsList;
	}

	public void addGift(String giftName, double price) {
		this.giftsList.add(new Gift(giftName, price));
	}

	public String getName() {
		return occasion;
	}


	public void setName(String name) {
		this.occasion = name;
	}

	public void removeGift(String giftName) {
		for (int i = 0; i < this.giftsList.size(); i++) {

			if(this.giftsList.get(i).getName().equals(giftName)) {
				this.giftsList.remove(i);
				break;
			}
		}
	}

	public static int getIndexOf(ArrayList<Gift> list, String name) {
		int x = -1;
		if(checkIfNameAvaible(list, name) == false) {
			for(int i = 0; i <list.size();i++) {

				if(list.get(i).getName().equals(name)) {
					x = i;
				}
			}
		}
		return x;
	}

	public static boolean checkIfNameAvaible(ArrayList<Gift> list, String name) {
		for(int i =0; i < list.size();i++) {
			if(list.get(i).getName().equals(name)) {
				return false;
			}
		}return true;

	}
}
