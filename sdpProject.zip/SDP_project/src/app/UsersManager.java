package app;

import java.util.ArrayList;

public class UsersManager {

	private static ArrayList<User> usersList;
	public static User currentUser;
	// Singleton Pattern ------------------------------------------------------
	private static UsersManager instance;

	private UsersManager() {
		usersList = new ArrayList<User>();
		currentUser = new User(null, null);

	}

	public static UsersManager getInstance() {
		if(instance == null)
			synchronized (UsersManager.class) {
				if(instance == null)
					instance = new UsersManager();
			}
		return instance;
	}
	public static ArrayList<User> getUsersList(){
		return usersList;
	}
	// Singleton Pattern -------------------------------------------------------

	public void help() {
		System.out.println();
		for(String i: help) {
			System.out.println(i);
		};
	}
	public void addUser(String userName, String password ) {
		if(checkIfNameAvaible(usersList, userName)) {
			usersList.add(new User(userName, password));
		}else {
			System.out.println("This username is already taken, please use another one");
		}

	}

	public static boolean checkIfNameAvaible(ArrayList<User> list, String name) {
		for(int i =0; i < list.size();i++) {
			if(list.get(i).getName().equals(name)) {
				return false;
			}
		}return true;

	}


	public static boolean checkIfNameAvaible(ArrayList<User> list, User user) {
		for(int i =0; i < list.size();i++) {
			if(list.get(i).equals(user)) {
				return false;
			}
		}return true;

	}

	public static int getIndexOfUser(ArrayList<User> list, String userName) {
		int x = -1;
		if(checkIfNameAvaible(list, userName) == false) {
			for(int i = 0; i <list.size();i++) {

				if(list.get(i).getName().equals(userName)) {
					x = i;
				}
			}
		}
		return x;
	}

	/*public int getIndexUsersList(String userName) {
		return getIndexOfUser(usersList, userName);
	}*/

	public void showAllUsers() {
		System.out.println();
		System.out.println("List of all users:");
		System.out.println("lp. | User Name");
		for(int i = 0; i < usersList.size();i++) {
			System.out.println(i+1 + ". " + usersList.get(i).getName());
		}
	}
	private String[] help = {
			"List of all commands :",
			"",
			"For UsersManager.getInstance():",
			"addUser",
			"showAllUsers",
			"",
			"For UsersManager.currentUser:",
			"login",
			"addOccasion",
			"removeOccasion",
			"addGift",
			"removeGift",
			"showYourGifts",
			"changeGiftPrice",
			"changeGiftName",
			"changeGiftStatus",
			"addFriend",
			"removeFriend",
			"showFriends()",
			"showAllGiftsOfYourFriend",
			"changeFriendGiftStatus"
	};

}


