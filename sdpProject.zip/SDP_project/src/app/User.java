package app;

import java.util.ArrayList;
import app.UsersManager;

public class User {
	private String userName;
	private String password;
	private ArrayList<GiftsGroup>ownerLists;
	private ArrayList<User>friendsList;

	public User(String userName, String password){
		this.userName = userName;
		this.password = password;
		ownerLists = new ArrayList<GiftsGroup>();
		friendsList = new ArrayList<User>();
	}

	public String getName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public void setName(String name) {
		this.userName = name;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ArrayList<User> getFriendsList(){
		return friendsList;
	}

	/*public void addGiftsGroup(GiftsGroup occasionName) {
		this.ownerLists.add(occasionName);
	}*/

	public ArrayList<GiftsGroup> getOwnerlists(){
		return this.ownerLists;
	}
	public void changeFriendGiftStatus(String friendName, String occasionName, String giftName) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(friendsList, friendName) == false) {
			if(checkIfNameAvaible(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName) == false) {
				if(GiftsGroup.checkIfNameAvaible(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList(), giftName) == false) {
					if(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList(), giftName)).getStatus() == false) {
						UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList(), giftName)).setIsBoughtStatus();
						System.out.println("Status of " + giftName + " has been changed to 'true' (gift is already bought");
					}else {
						UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists().get(getIndexOf(UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists(), occasionName)).getGiftsList(), giftName)).setIsNotBoughtStatus();
						System.out.println("Status of " + giftName + " has been changed to 'false' (gift hasn't been bought yet");
					}	
				}
				else {
					System.out.println("Given gift name does not exist on your list");
				}
			}else {
				System.out.println("Given occasion does not exist on your list");
			}
		}else {
			System.out.println("There is no " + friendName + " on the friends list");
		}
	}

	public void changeGiftStatus(String occasionName, String giftName) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			if(GiftsGroup.checkIfNameAvaible(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName) == false) {
				if(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)).getStatus() == false) {
					ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)).setIsBoughtStatus();
					System.out.println("Status of " + giftName + " has been changed to 'true' (gift is already bought");
				}else {
					ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)).setIsNotBoughtStatus();
					System.out.println("Status of " + giftName + " has been changed to 'false' (gift hasn't been bought yet");
				}	
			}
			else {
				System.out.println("Given gift name does not exist on your list");
			}
		}else {
			System.out.println("Given occasion does not exist on your list");
		}
	}

	public void changeGiftName(String occasionName, String giftName, String newGiftName) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			if(GiftsGroup.checkIfNameAvaible(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName) == false) {
				ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)).setName(newGiftName);
				System.out.println("Gift's name has been succesfully changed");
			}else {
				System.out.println("Given gift name does not exist on your list");
			}
		}else {
			System.out.println("Given occasion does not exist on your list");
		}

	}

	public void changeGiftPrice(String occasionName, String giftName, double newPrice) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			if(GiftsGroup.checkIfNameAvaible(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName) == false) {
				ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().get(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)).setPrice(newPrice);;
				System.out.println("Gift's price has been succesfully changed");
			}
			else {
				System.out.println("Given gift name does not exist on your list");
			}
		}else {
			System.out.println("Given occasion does not exist on your list");
		}	
	}

	public void showYourGifts() {
		System.out.println();
		System.out.println("List of your wished gifts:");
		for(GiftsGroup occasion: ownerLists) {
			System.out.println();
			System.out.println(occasion.getName() + " :");
			System.out.println("Name | Price | Is already bought?");
			for(Gift gift: occasion.getGiftsList()) {
				System.out.println(gift.getName() + " | " + gift.getPrice() + " | " + gift.getStatus());
			}
		}
	}

	/*public void showEventsOfYourFriend(String friendName) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(friendsList, friendName) == false) {
			System.out.println("Events list of your friend " + friendName);
			for(GiftsGroup i: UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists()) {
				System.out.println(i.getName());
			}
		}
		System.out.println("There is no " + friendName + " on the friends list");
	}*/

	/*public void showGiftsOfYourFriend(String friendName, String occasionName) {

	}*/

	public void showAllGiftsOfYourFriend(String friendName) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(friendsList, friendName) == false) {
			System.out.println("Gifts list of your friend " + friendName);
			for(GiftsGroup occasion: UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), friendName)).getOwnerlists()) {
				System.out.println();
				System.out.println(occasion.getName() + " :");	
				System.out.println("Name | Price | Is already bought?");
				for(Gift gift: occasion.getGiftsList()) {
					System.out.println(gift.getName() + " | " + gift.getPrice() + " | " + gift.getStatus());	
				}
			}
		}else {
			System.out.println("There is no " + friendName + " on the friends list");
		}	
	}

	public void addGift(String occasionName, String giftName, double price) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			if(GiftsGroup.checkIfNameAvaible(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName)) {
				ownerLists.get(getIndexOf(ownerLists, occasionName)).addGift(giftName, price);
				System.out.println(occasionName + " has been succesfully added to " + occasionName + " list");
			}else {
				System.out.println("Given gift is already on your list");
			}	
		}else {
			System.out.println("Given occasion does not exist on your list");
		}
	}

	public void removeGift(String occasionName, String giftName) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			if(GiftsGroup.checkIfNameAvaible(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName) == false) {
				ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList().remove(GiftsGroup.getIndexOf(ownerLists.get(getIndexOf(ownerLists, occasionName)).getGiftsList(), giftName));
				System.out.println(giftName + " has been succesfully removed from " + occasionName + " list");
			}else {
				System.out.println("Given gift name does not exist on your list");
			}
		}else {
			System.out.println("Given occasion does not exist on your list");
		}
	}

	public void addOccasion(String occasionName) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName)) {
			ownerLists.add(new GiftsGroup(occasionName));
			System.out.println("You have succesfully added " + occasionName + " to your occasions list");
		}else {
			System.out.println("Given occasion is already added to your list");
		}
	}

	public void removeOccasion(String occasionName) {
		System.out.println();
		if(checkIfNameAvaible(ownerLists, occasionName) == false) {
			ownerLists.remove(getIndexOf(ownerLists, occasionName));
			System.out.println("You have succesfully removed " + occasionName + " from your occasions list");
		}
		System.out.println("Given occasion does not exist on your list");
	}

	public void showFriends() {
		System.out.println();
		System.out.println("List of friends:");
		System.out.println("lp. | friend's name");
		for(int i = 0; i < friendsList.size();i++) {
			System.out.println(i+1 + ". " + friendsList.get(i).getName());
		}
	}

	public void login(String userName, String password) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(UsersManager.getUsersList(), userName) == false) {
			boolean isLoggedIn = false;
			for(int i = 0 ; i < UsersManager.getUsersList().size() ; i++) {
				if(UsersManager.getUsersList().get(i).getName().equals(userName) && UsersManager.getUsersList().get(i).getPassword().equals(password)) {
					UsersManager.currentUser = UsersManager.getUsersList().get(i);
					System.out.println("You are logged in as " + userName);
					isLoggedIn = true;
					break;
				}
			}
			if(isLoggedIn == false)
				System.out.println("Given password is incorrect");
		}else {
			System.out.println("Given User Name is incorrect");
		}

	}

	/*public int getIndexFriendsList(String friendName) {
		return UsersManager.getIndexOfUser(this.friendsList, friendName);
	}*/

	/*public void addFriend(User user) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(this.friendsList, user)) {
			if(UsersManager.checkIfNameAvaible(UsersManager.getUsersList(), user) == false) {
				this.friendsList.add(user);
				System.out.println(user.getName() + " has been succesfully added to your friends list");
			}else {
				System.out.println("Given name is not on list of users");
			}

		}else {
			System.out.println("This user has been already added to your friends list");
		}
	}*/

	public void addFriend(String userName) {
		System.out.println();
		if(!(this.userName.equals(userName))) {
			if(UsersManager.checkIfNameAvaible(friendsList, userName)) {

				if(UsersManager.checkIfNameAvaible(UsersManager.getUsersList(), userName) == false) {

					for(int i =0; i <UsersManager.getUsersList().size();i++) {

						if(UsersManager.getUsersList().get(i).getName().equals(userName)) {

							this.friendsList.add(UsersManager.getUsersList().get(i));
							UsersManager.getUsersList().get(UsersManager.getIndexOfUser(UsersManager.getUsersList(), userName)).addFriend(this.userName);
							System.out.println(userName + " has been succesfully added to your friends list");
							break;
						}
					}
				}else {
					System.out.println("Given name is not on list of users");
				} 
			}else {
				System.out.println("This user has been already added to your friends list");
			}
		}else {
			System.out.println("You cannot add yourself to your friends list");
		}
	}

	/*public void removeFriend(User user) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(UsersManager.getUsersList(), user) == false) {
			if(UsersManager.checkIfNameAvaible(friendsList, user) == false) {
				this.friendsList.remove(user);
				System.out.println(user.getName() + " has been succesfully removed from your friends list");
			}else {
				System.out.println("This user has been already removed from your friends list");
			}

		}else {
			System.out.println("Given name is not on list of users");
		}

	}*/

	public void removeFriend(String userName) {
		System.out.println();
		if(UsersManager.checkIfNameAvaible(UsersManager.getUsersList(), userName) == false) {

			if(UsersManager.checkIfNameAvaible(friendsList, userName) == false) {

				for(int i =0; i < this.friendsList.size();i++) {
					if(this.friendsList.get(i).getName().equals(userName)) {
						this.friendsList.remove(i);
						System.out.println(userName + " has been succesfully removed from your friends list");
						break;
					}
				}
			}else {
				System.out.println("This user has been already removed from your friends list");
			} 
		}else {
			System.out.println("Given name is not on list of users");
		}	
	}

	public static boolean checkIfNameAvaible(ArrayList<GiftsGroup> list, String name) {
		for(int i =0; i < list.size();i++) {
			if(list.get(i).getName().equals(name)) {
				return false;
			}
		}return true;

	}

	public static int getIndexOf(ArrayList<GiftsGroup> list, String name) {
		int x = -1;
		if(checkIfNameAvaible(list, name) == false) {
			for(int i = 0; i <list.size();i++) {

				if(list.get(i).getName().equals(name)) {
					x = i;
				}
			}
		}
		return x;
	}
}