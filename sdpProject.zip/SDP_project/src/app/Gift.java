package app;

public class Gift {
	private String giftName;
	private double price;
	private boolean isBought;
	private GiftContext context;
	private GiftIsBought giftIsBought;
	private GiftIsNotBought giftIsNotBought;

	public Gift(String giftName, double price){
		this.giftName = giftName;
		this.price = price;
		context = new GiftContext();
		giftIsBought = new GiftIsBought();
		giftIsNotBought = new GiftIsNotBought();
		giftIsNotBought.changeStatus(this.context);
	}

	public String getName() {
		return this.giftName;
	}

	public double getPrice() {
		return this.price;
	}

	public boolean getStatus() {
		return this.isBought;
	}

	public void setName(String giftName) {

		this.giftName = giftName;
	}

	public void setPrice(double price) {

		this.price = price;
	}

	public void setIsBoughtStatus() {	
		giftIsBought.changeStatus(context);

	}
	public void setIsNotBoughtStatus() {
		giftIsNotBought.changeStatus(context);

	}
	//State Pattern beginning ---------------------------------------
	interface GiftState{

		public void changeStatus(GiftContext context);
	}

	class GiftContext{
		private GiftState state;

		public void setState(GiftState state) {
			this.state = state;
		}

		public GiftState getState() {
			return state;
		}

		public void changeStatus() {
			state.changeStatus(this);
		}
	}

	class GiftIsBought implements GiftState{
		@Override
		public void changeStatus(GiftContext context) {

			isBought = true;
			context.setState(this);
		}
	}

	class GiftIsNotBought implements GiftState{

		@Override
		public void changeStatus(GiftContext context) {

			isBought = false;
			context.setState(this);
		}

	}
	//State Pattern ending --------------------------------------------
}