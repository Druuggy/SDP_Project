package runApp;
import app.UsersManager;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		//UsersManager manager = new UsersManager();

		UsersManager manager = UsersManager.getInstance();
		manager.help();
		/*
		manager.addUser("Jan", "123");
		manager.addUser("Mateusz", "asd");
		manager.addUser("Piotr", "qwer");
		manager.addUser("Tomek", "098");

		UsersManager.currentUser.login("Jan", "123");
		UsersManager.currentUser.addFriend("Mateusz");
		UsersManager.currentUser.addFriend("Piotr");
		UsersManager.currentUser.addFriend("Tomek");
		UsersManager.currentUser.showFriends();
		UsersManager.currentUser.removeFriend("Tomek");
		UsersManager.currentUser.showFriends();

		UsersManager.currentUser.addGift("lalal", "jajajja", 123);
		UsersManager.currentUser.addOccasion("Urodziny");
		UsersManager.currentUser.addOccasion("Swieta");

		UsersManager.currentUser.addGift("Urodziny", "Telewizor", 4000);
		UsersManager.currentUser.addGift("Urodziny", "Konsola", 1000);
		UsersManager.currentUser.addGift("Urodziny", "Czajnik", 40000);
		UsersManager.currentUser.addGift("Swieta", "Czapka", 100);
		UsersManager.currentUser.showYourGifts();
		UsersManager.currentUser.login("Mateusz", "asd");
		UsersManager.currentUser.showFriends();

		UsersManager.currentUser.showAllGiftsOfYourFriend("Jan");
		UsersManager.currentUser.changeFriendGiftStatus("Jan", "Urodziny", "Konsola");
		UsersManager.currentUser.changeFriendGiftStatus("Piotr", "Urodziny", "Konsola");
		UsersManager.currentUser.showAllGiftsOfYourFriend("Jan");
		UsersManager.currentUser.login("Jan", "123");
		UsersManager.currentUser.showYourGifts();
		 */



	}

}
